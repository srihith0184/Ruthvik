const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const port = 3000
var cors = require('cors')
app.use(cors()) 
const db = require('./pg')

var stripe = require('stripe')('Your_Secret_Key');

const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'ruthvik',
  port: 5432,
})

app.get('/users', db.getUsers)


app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)

app.get('/', (request, response) => {
    response.json({ info: 'Node.js, Express, and Postgres API' })
  })

  
  app.listen(port, () => {
    console.log(`App running on port ${port}.`)
  })



app.get('/userlogin', function(req, res){ 
  
  let username = req.query.username;
  let password = req.query.password;
  let userrole = req.query.userrole;
  console.log("Name :", username) 

  pool.query('SELECT * FROM mgit_login where username = $1 and password = $2 and userrole = $3',[username,password,userrole], (error, results) => {
    if (error) {
      throw error
    }
    console.log(results.rows)
    res.status(200).json(results.rows)
  })
  

}) 

app.get('/viewroute', function(req, res){ 
  
  pool.query('SELECT * FROM mgit_bus_route', (error, results) => {
    if (error) {
      throw error
    }
    console.log(results.rows)
    res.status(200).json(results.rows)
  })
  

}) 



app.post('/registerstudent', function (req, res) {  

  let studentName = req.body.studentName;
  let rollNumber = req.body.rollNumber;
  let phoneNumber = req.body.phoneNumber;
  let email = req.body.email;
  let userName = req.body.userName;
  let password = req.body.password;
  let branch = req.body.branch;
  let gender = req.body.gender;
  let accademic = req.body.accademic;
  let userrole="student";



  let queryString='INSERT INTO mgit_student_details (username,password,userrole,student_name,roll_number,phone_no,email,branch,gender,accademic) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)';

  pool.query(queryString,[userName,password,userrole,studentName,rollNumber,phoneNumber,email,branch,gender,accademic], (error, results) => {
    if (error) {
      throw error
    }
    console.log(results.rows)
    res.status(201).json(results.rows)
  })


  console.log(userName);  
  res.end(JSON.stringify(userName));  
})  


app.post('/registeremployee', function (req, res) {  

  let empName = req.body.empName;
  let empDesgn = req.body.empDesgn;
  let phoneNumber = req.body.phoneNumber;
  let email = req.body.email;
  let userName = req.body.userName;
  let password = req.body.password;
  let gender = req.body.gender;
  let userrole="employee";



  let queryString='INSERT INTO mgit_employee_details (username,password,userrole,empname,empdesgn,phone_no,email,gender) values($1,$2,$3,$4,$5,$6,$7,$8)';

  pool.query(queryString,[userName,password,userrole,empName,empDesgn,phoneNumber,email,gender], (error, results) => {
    if (error) {
      throw error
    }
    console.log(results.rows)
    res.status(201).json(results.rows)

    
  })
  console.log(userName);  
  res.end(JSON.stringify(userName));  
})  

app.post('/applypass', function (req, res) {  

  let username = req.body.username;
  let name = req.body.name;
  let phoneNumber = req.body.phoneNumber;
  let email = req.body.email;
  let place = req.body.place;
  let buscost = req.body.buscost;
  let status="pending";



  let queryString='INSERT INTO mgit_bus_pass (name,phone_no,email,place,buscost,status,username) values($1,$2,$3,$4,$5,$6,$7)';

  pool.query(queryString,[name,phoneNumber,email,place,buscost,status,username], (error, results) => {
    if (error) {
      throw error
    }
    console.log(results.rows)
    res.status(201).json(results.rows)

    
  })

}) 
  

  app.post('/createroute', function (req, res) {  

    let regnumber= req.body.regnumber;
    let drivername= req.body.drivername;
    let driverphoneno= req.body.driverphoneno;
    let inchargename= req.body.inchargename;
    let inchargeemail= req.body.inchargeemail;
    let inchargephone= req.body.inchargephone;
    let inchargeusername= req.body.inchargeusername;
    let inchargepassword= req.body.inchargepassword;
    let buscapacity= req.body.buscapacity;
    let busstartingpoint= req.body.busstartingpoint;
    let starttime= req.body.starttime;
    let endtime= req.body.endtime;
    let buscost= req.body.buscost;
    let userrole="busincharge";
  
  
  
    let queryString='INSERT INTO mgit_bus_route (username,password,userrole,regnumber,drivername,driverphoneno,inchargename,inchargeemail,inchargephone,buscapacity,busstartingpoint,starttime,endtime,buscost) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)';
  
    pool.query(queryString,[inchargeusername,inchargepassword,userrole,regnumber,drivername,driverphoneno,inchargename,inchargeemail,inchargephone,buscapacity,busstartingpoint,starttime,endtime,buscost], (error, results) => {
      if (error) {
        throw error
      }
    })
  
  })  

  app.post('/approverequest', function (req, res) {  

    let username = req.body.username;
    let name = req.body.name;
    let phoneNumber = req.body.phoneNumber;
    let email = req.body.email;
    let place = req.body.place;
    let buscost = req.body.buscost;
    let status="approve";
  
  
  
    let queryString='update mgit_bus_pass set status=$1';
  
    pool.query(queryString,[status], (error, results) => {
      if (error) {
        throw error
      }
      console.log(results.rows)
      res.status(201).json(results.rows)
  
      
    })

  })  



  app.get('/viewrequest', function(req, res){ 
  
    let status='pending';
    pool.query('SELECT * FROM mgit_bus_pass where status=$1',[status], (error, results) => {
      if (error) {
        throw error
      }
      console.log(results.rows)
      res.status(200).json(results.rows)
    })
    
  
  }) 



  app.get('/viewinchargedetails', function(req, res){ 
  
    let username = req.query.username;

    pool.query('SELECT * FROM mgit_bus_pass', (error, results) => {
      if (error) {
        throw error
      }
      console.log(results.rows)
      res.status(200).json(results.rows)
    })
    
  
  }) 



