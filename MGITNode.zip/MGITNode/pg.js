const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'ruthvik',
  port: 5432,
})


const getUsers = (request, response) => {
    pool.query('SELECT * FROM mgit_user', (error, results) => {
      if (error) {
        throw error
      }
      console.log(results.rows)
      response.status(200).json(results.rows)
    })
  }


  const getLogin = (request, response) => {
    pool.query('SELECT * FROM mgit_login', (error, results) => {
      if (error) {
        throw error
      }
      console.log(results.rows)
      response.status(200).json(results.rows)
    })
  }

  
  const userLogin = (request,response) => {

    
    console.log(username)
    pool.query('SELECT * FROM mgit_login where username = $1 and password = $2 and userrole = $3',[username,password,userrole], (error, results) => {
      if (error) {
        throw error
      }
      console.log(results.rows)
      response.status(200).json(results.rows)
    })
  }

  
module.exports = {
    getUsers,
    userLogin
  }